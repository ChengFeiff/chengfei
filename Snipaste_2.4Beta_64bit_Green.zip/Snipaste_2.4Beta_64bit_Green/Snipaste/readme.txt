# Snipaste

If Snipaste fails to run, you may find the solutions here:
https://docs.snipaste.com/troubleshooting

The documentation can also be found in Snipaste's tray menu.

====

如果 Snipaste 无法运行，请打开以下网址寻求解决方案：
https://docs.snipaste.com/zh-cn/troubleshooting

成功运行后，如有任何疑问，可先查阅相关帮助文档（在 Snipaste 托盘图标的右键菜单中）。
